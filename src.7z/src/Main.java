import java.io.IOException;
import java.util.stream.Stream;

public class Main {

    public static void main(String[] args) throws IOException {
        Stream<String> stream = ParserFile.parse("./ressource/source/b_read_on.txt");
        stream = TransformFile.transform(stream);
        ParserFile.write(stream,"./ressource/reponse/b_read_on.txt");
    }
}
